import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-statements',
  templateUrl: './view-statements.component.html',
  styleUrls: ['./view-statements.component.css']
})
export class ViewStatementsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
