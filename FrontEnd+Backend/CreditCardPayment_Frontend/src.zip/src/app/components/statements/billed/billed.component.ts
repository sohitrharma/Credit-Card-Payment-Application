import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-billed',
  templateUrl: './billed.component.html',
  styleUrls: ['./billed.component.css']
})
export class BilledComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
