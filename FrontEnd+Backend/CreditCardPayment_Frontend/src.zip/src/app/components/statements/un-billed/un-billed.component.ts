import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-un-billed',
  templateUrl: './un-billed.component.html',
  styleUrls: ['./un-billed.component.css']
})
export class UnBilledComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
