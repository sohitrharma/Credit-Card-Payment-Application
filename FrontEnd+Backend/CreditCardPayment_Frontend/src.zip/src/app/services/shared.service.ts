import { Injectable } from '@angular/core';
import { User } from 'src/models/user';

@Injectable({
  providedIn: 'root'
})
export class SharedService {
  currentCustomer: User = new User();
  constructor() { }

  setCurrentCustomer(customer: User): void {
    this.currentCustomer = customer;
  }
  getCurrentCustomer(): User {
    return this.currentCustomer;
  }
}

