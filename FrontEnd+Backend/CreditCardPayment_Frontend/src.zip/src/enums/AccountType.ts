export enum AccountType {
	SAVINGS, CURRENT

}