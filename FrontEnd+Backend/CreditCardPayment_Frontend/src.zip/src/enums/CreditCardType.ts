export enum CreditCardType {
	VISA, MASTERCARD

}