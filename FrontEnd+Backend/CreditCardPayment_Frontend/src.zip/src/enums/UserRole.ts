export enum UserRole {
	CUSTOMER, ADMIN

}