package com.cg.creditcard.util;

public class AccountConstants {
	//error messages
	public static final String ACCOUNT_NOT_FOUND_BY_ACCOUNTNUMBER ="Account not found for the given Account Number!! Try again...";
	public static final String ACCOUNT_NOT_GET_BY_ACCOUNTNUMBER ="Something went wrong!!! Please enter valid details... Try again...";
}
