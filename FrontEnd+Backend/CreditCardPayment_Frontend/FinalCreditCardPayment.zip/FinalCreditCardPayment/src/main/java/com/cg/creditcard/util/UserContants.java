package com.cg.creditcard.util;

public class UserContants {
	//Error constants
	public static final String USER_NOT_FOUND_BY_ID_CONST = "Customer not found for User Id: ";
	public static final String INVALID_USER_CONST = "Something went wrong: ";
}
