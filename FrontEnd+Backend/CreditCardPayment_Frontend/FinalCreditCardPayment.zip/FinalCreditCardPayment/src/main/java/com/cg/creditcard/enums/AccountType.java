package com.cg.creditcard.enums;

public enum AccountType {
	SAVINGS,CURRENT;
}
