package com.cg.creditcard.enums;

public enum UserRole {
	CUSTOMER,ADMIN;
}
