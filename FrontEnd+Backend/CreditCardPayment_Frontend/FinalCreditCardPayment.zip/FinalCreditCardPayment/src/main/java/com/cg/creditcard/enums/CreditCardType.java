package com.cg.creditcard.enums;

public enum CreditCardType {
	VISA, MASTERCARD;

}
