package com.cg.creditcard.util;

public class PaymentConstants {
	
	public static final String PAYMENT_NOT_FOUND_BY_ID_CONST = "Payment not found for Payment Id: ";
	public static final String PAYMENT_NOT_FOUND_BY_NUMBER_CONST = "Payment not found for Type: ";
	public static final String INVALID_PAYMENT_CONST = "Something went wrong: ";

}
