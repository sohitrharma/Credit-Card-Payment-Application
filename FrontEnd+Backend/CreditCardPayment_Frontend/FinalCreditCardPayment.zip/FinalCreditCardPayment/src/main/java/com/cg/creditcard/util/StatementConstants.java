package com.cg.creditcard.util;

public class StatementConstants {

	public static final String STATEMENT_NOT_FOUND_BY_ID_CONST = "Customer not found for User Id: ";
	public static final String INVALID_STATEMENT_CONST = "Something went wrong: ";
}
