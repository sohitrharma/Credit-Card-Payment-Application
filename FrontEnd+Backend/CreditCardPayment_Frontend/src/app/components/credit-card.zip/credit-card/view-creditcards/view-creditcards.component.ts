import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Observable, Subject } from 'rxjs';
import { CreditcardServiceService } from 'src/app/services/creditcard-service.service';
import { CreditCard } from 'src/models/CreditCard';

@Component({
  selector: 'app-view-creditcards',
  templateUrl: './view-creditcards.component.html',
  styleUrls: ['./view-creditcards.component.css']
})
export class ViewCreditcardsComponent implements OnInit {

  constructor(private router: Router,private creditcardService:CreditcardServiceService) { }  
  
  creditcardsArray: any[] = [];  
  dtOptions: DataTables.Settings = {};  
  dtTrigger: Subject<any>= new Subject();  
  
  creditcards: Observable<CreditCard[]>;  
  creditcard : CreditCard=new CreditCard();  
  deleteMessage=false;  
  editForm: FormGroup;
  creditcardlist:any;  
  isupdated = false;      
  userId=10;

  // totalRecords:String;
  // page :number=1;
  
  ngOnInit() {  
    this.isupdated=false;  
    this.dtOptions = {  
      pageLength: 6,  
      stateSave:true,  
      lengthMenu:[[6, 16, 20, -1], [6, 16, 20, "All"]],  
      processing: true  
    };     
    this.creditcardService.getAllCreditCards().subscribe(data =>{  
    this.creditcards =data.response;  
    this.dtTrigger.next();  
    }) 
   
  }  

  deleteCreditCard(id: number) {  
    this.creditcardService.deleteCreditCard(id)  
      .subscribe(  
        data => {  
          console.log(data);  
          this.deleteMessage=true;  
          this.creditcardService.getAllCreditCards().subscribe(data =>{  
            this.creditcards =data.response  
            })  
        },  
        error => console.log(error));  
  }  

  updateCreditCard(id: number){  
    console.log("id"+id);
    this.creditcardService.getCreditCardById(id)  
      .subscribe(  
        data => {  
          this.creditcardlist=data.response  ;
          this.creditcardlist=Array.of(this.creditcardlist);
          console.log(this.creditcardlist)   ;        
        },  

        error => console.log(error));  
  }  

  creditcardupdateform=new FormGroup({  
    cardId:new FormControl(),
    cardName: new FormControl(),
    cardNumber: new FormControl(),
    cardType: new FormControl(),
    bankName: new FormControl(),
    cardExpiry: new FormControl(),
    cvv:new FormControl()
  });  

  updatecc(abc) {
    this.creditcard = new CreditCard;
    this.creditcard.cardId = this.CardId.value;
    this.creditcard.cardName = this.CardName.value;
    this.creditcard.cardNumber = this.CardNumber.value;
    this.creditcard.cardType = this.CardType.value;
    this.creditcard.bankName = this.BankName.value;
    this.creditcard.cardExpiry = this.ExpiryDate.value;
    this.creditcard.cvv=this.CVV.value;
    console.log(this.CardType.value);  
     
  
   this.creditcardService.updateCreditCard(this.creditcard.cardId,this.creditcard).subscribe(  
    data => {       
      this.isupdated=true;  
      this.creditcardService.getAllCreditCards().subscribe(data =>{  
        this.creditcards =data.response
        })  
    },  
    error => console.log(error));  
  }  

  get CardName(){
    return this.creditcardupdateform.get('cardName');
  }

  
  get CardNumber(){
    return this.creditcardupdateform.get('cardNumber');
  }

  get CardType(){
    return this.creditcardupdateform.get('cardType');
  }
  get CardId(){
    return this.creditcardupdateform.get('cardId');
  }
  get BankName(){
    return this.creditcardupdateform.get('bankName');
  }

  get ExpiryDate(){
    return this.creditcardupdateform.get('cardExpiry');
  }

  get CVV(){
    return this.creditcardupdateform.get('cvv');
  }

  changeisUpdate(){  
    this.isupdated=false;  
  }  

  addCreditCard(): void {
    this.router.navigate(['/creditcard/add/10']);
  };

}
