import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-creditcard',
  templateUrl: './update-creditcard.component.html',
  styleUrls: ['./update-creditcard.component.css']
})
export class UpdateCreditcardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
